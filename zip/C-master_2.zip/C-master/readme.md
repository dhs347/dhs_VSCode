#谈谈C
C语言把内存空间的操作留给我们，它们让我们对自己写的程序“一目了然”。计算空间
==>指针操作==>数据结构==>算法。我们不能做什么？我们不能控制计算机的CPU读取内
存中的数据，需要找汇编语言帮忙来操作寄存器。从数据的构建上来说，这是C语言的
唯一好处。
#[KERNEL](https://github.com/yaouser/C/tree/master/kernel)
既然知道这个大写的C字母是干什么用的?为什么不看看linux kernel是怎么工作呢?壮丽
的风景在这里:)[linux kernel](https://github.com/yaouser/C/tree/master/kernel).
