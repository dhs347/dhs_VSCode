#define LAG >
#define SMA <
#define EQ ==
