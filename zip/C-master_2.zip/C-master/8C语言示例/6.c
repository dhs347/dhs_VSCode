#include <stdio.h>
int main(int argc, char *argv[])
{
  printf ("Hello C-world!\n");
  printf ("****\n");
  printf ("*\n");
  printf ("*\n");
  printf ("****\n");
  return 0;
}
