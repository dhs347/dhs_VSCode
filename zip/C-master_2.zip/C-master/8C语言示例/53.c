#include <stdio.h>
main()
{
  int a,b;
  a=077;
  b=a^3;
  printf ("the a&b(decimal) is %d\n",b);
  b^=7;
  printf ("the a&b(decimal) is %d\n",b);
}
