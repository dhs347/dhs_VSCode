<!--------------------------------------------------------

Thanks for contributing to the All ▲lgorithms Project

Make sure you fill the require information
---------------------------------------------------------->

This issue is: <!-- THIS IS REQUIRE -->

<!-- Mark one by adding an [x] -->

- [ ] A new Algorithm
- [ ] An update to an existing algorithm.
- [ ] An error found
- [ ] A proposal
- [ ] A question
- [ ] Other (Describe below*)

**Description:**

<!-- THIS IS NOT REQUIRE unless you have selected other -->
