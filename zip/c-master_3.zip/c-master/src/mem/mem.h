
void *xmalloc(int);
char *xstrdup(char *);
