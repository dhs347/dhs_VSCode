
long long atoll(const char *);
void  qsort(void *, long , long ,int (*)(const void *, const void *));
void *malloc(long size);
void  exit(int);
