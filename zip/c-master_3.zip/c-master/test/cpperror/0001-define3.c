/*
PATTERN: garbage
PATTERN: c:7:
*/

#define X
#undef X asdfad


