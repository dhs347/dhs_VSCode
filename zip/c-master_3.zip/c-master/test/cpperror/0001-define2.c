/*
PATTERN: undef
PATTERN: c:6:
*/

#undef X

