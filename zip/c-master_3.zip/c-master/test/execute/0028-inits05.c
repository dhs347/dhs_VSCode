
int x = 5;
int *p = &x;

int
main()
{
	if(*p != 5)
		return 1;
	return 0;
}
