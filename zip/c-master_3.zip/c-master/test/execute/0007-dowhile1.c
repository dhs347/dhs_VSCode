int 
main()
{
	int x;
	
	x = 0;
	do 
	  x = x + 1;
	while(x < 10);
	
	do {
	  x = x + 1;
	} while(x < 20);
	
	return x - 20;
}

