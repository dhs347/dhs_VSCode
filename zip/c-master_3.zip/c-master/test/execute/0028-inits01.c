
int x = 5;

int
main()
{
	if(x != 5) 
		return 1;
	return 0;
}
