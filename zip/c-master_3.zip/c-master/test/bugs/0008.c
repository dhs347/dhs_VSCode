
int main()
{
	int x;

	x = 2;
	if(!(x == 2))
		return 1;
	return 0;
}