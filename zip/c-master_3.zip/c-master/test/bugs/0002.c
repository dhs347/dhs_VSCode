int
main()
{
	long long x;
	x = 0;
	return x;
}
