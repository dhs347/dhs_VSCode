

int
main()
{

	int i;
	
	for(i = 0; i < 3; i++)
		continue;
	return 0;
}

