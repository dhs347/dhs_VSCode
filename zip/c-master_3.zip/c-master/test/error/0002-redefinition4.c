/*
PATTERN: x
PATTERN: typedef
PATTERN: c:9
*/

typedef int  x;
typedef int  x;
typedef int *x;
