/*
PATTERN: wrong size
PATTERN: c:6:
*/

int arr[3] = {[5] = 4};

