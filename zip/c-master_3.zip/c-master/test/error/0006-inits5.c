
/*
PATTERN: incomplete
PATTERN: c:6:
*/
struct S s = {1};

