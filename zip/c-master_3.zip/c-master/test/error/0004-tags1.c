/*
PATTERN: redefinition
PATTERN: c:8:
*/

struct X;
struct X {};
struct X {int x;};
