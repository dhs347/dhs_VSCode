/*
PATTERN: tag
PATTERN: c:7:
*/

enum   X;
struct X;
